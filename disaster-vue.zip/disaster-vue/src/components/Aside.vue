<template>
  <el-menu  style="min-height: 100%; overflow-x: hidden"
           background-color="rgb(48, 65, 86)"
           text-color="#fff"
           active-text-color="#ffd04b"
           :collapse-transition="false"
           :collapse="isCollapse"
           router
           unique-opened
  >
    <div style="height: 60px; line-height: 60px; text-align: center">
      <img src="../assets/logo.png" alt="" style="width: 20px; position: relative; top: 5px; right: 5px">

      <b style="color: white" v-show="logoTextShow">救灾物资管理系统</b>
    </div>
    <el-menu-item index="/home">
      <template slot="title">
        <i class="el-icon-house"></i>
        <span slot="title">主页</span>
      </template>
    </el-menu-item>
    <el-submenu :index="1+''">
      <template slot="title">
        <i class="el-icon-menu"></i>
        <span slot="title">系统管理</span>
      </template>
      <el-menu-item index="/user">
        <i class="el-icon-s-custom"></i>
        <span slot="title">用户管理</span>
      </el-menu-item>
      <el-menu-item index="/department">
        <i class="el-icon-s-home"></i>
        <span slot="title">部门管理</span>
      </el-menu-item>
      <el-menu-item index="/role">
        <i class="el-icon-s-home"></i>
        <span slot="title">角色管理</span>
      </el-menu-item>
      <el-menu-item index="/icon">
        <i class="el-icon-s-tools"></i>
        <span slot="title">图标管理</span>
      </el-menu-item>
      <el-menu-item index="/menu">
        <i class="el-icon-s-tools"></i>
        <span slot="title">菜单管理</span>
      </el-menu-item>
      <el-menu-item index="/file">
        <i class="el-icon-s-tools"></i>
        <span slot="title">文件管理</span>
      </el-menu-item>
    </el-submenu>
    <el-submenu index="2+''">
      <template slot="title">
        <i class="el-icon-s-platform"></i>
        <span slot="title">公告管理</span>
      </template>
      <el-menu-item index="/addNotice">
        <i class="el-icon-receiving"></i>
        <span slot="title">发布公告</span>
      </el-menu-item>
      <el-menu-item index="/notice">
        <i class="el-icon-receiving"></i>
        <span slot="title">公告列表</span>
      </el-menu-item>
    </el-submenu>
    <el-submenu :index="3+''">
      <template slot="title">
        <i class="el-icon-s-platform"></i>
        <span slot="title">物资管理</span>
      </template>
      <el-menu-item index="/product">
        <i class="el-icon-receiving"></i>
        <span slot="title">物资资料</span>
      </el-menu-item>
      <el-menu-item index="/stocks">
        <i class="el-icon-bank-card"></i>
        <span slot="title">物资库存</span>
      </el-menu-item>
      <el-menu-item index="/category">
        <i class="el-icon-s-promotion"></i>
        <span slot="title">物资分类</span>
      </el-menu-item>
    </el-submenu>
    <el-submenu index="4+''">
      <template slot="title">
        <i class="el-icon-camera"></i>
        <span slot="title">物资流向</span>
      </template>
      <el-menu-item index="/supplier">
        <i class="el-icon-s-promotion"></i>
        <span slot="title">物资来源</span>
      </el-menu-item>
      <el-menu-item index="/consumer">
        <i class="el-icon-s-promotion"></i>
        <span slot="title">物资去处</span>
      </el-menu-item>
    </el-submenu>
    <el-submenu :index="5+''">
      <template slot="title">
        <i class="el-icon-camera"></i>
        <span slot="title">出库管理</span>
      </template>
      <el-menu-item index="/outAdd">
        <i class="el-icon-date"></i>
        <span slot="title">出库添加</span>
      </el-menu-item>
      <el-menu-item index="/outList">
        <i class="el-icon-date"></i>
        <span slot="title">出库列表</span>
      </el-menu-item>
    </el-submenu>
    <el-submenu :index="6+''">
      <template slot="title">
        <i class="el-icon-camera"></i>
        <span slot="title">入库管理</span>
      </template>
      <el-menu-item index="/inAdd">
        <i class="el-icon-date"></i>
        <span slot="title">入库添加</span>
      </el-menu-item>
      <el-menu-item index="/inList">
        <i class="el-icon-date"></i>
        <span slot="title">入库列表</span>
      </el-menu-item>
    </el-submenu>
    <el-submenu :index="7+''">
      <template slot="title">
        <i class="el-icon-camera"></i>
        <span slot="title">监控中心</span>
      </template>
      <el-menu-item index="/log">
        <i class="el-icon-date"></i>
        <span slot="title">日志管理</span>
      </el-menu-item>
    </el-submenu>
  </el-menu>
</template>

<script>
export default {
  name: "Aside",
  props: {
    isCollapse: Boolean,
    logoTextShow: Boolean
  },
  methods: {

  }
}
</script>

<style scoped>

</style>