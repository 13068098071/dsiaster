import Vue from 'vue'
import VueRouter from 'vue-router'
import store from "@/store";

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    component: () => import('../views/Manage.vue'),
    redirect: "/home",
    children: [
      { path: 'home', name: '首页', component: () => import('../views/Home.vue')},
      { path: 'department', name: '部门管理', component: () => import('../views/sys/Department.vue')},
      { path: 'password', name: '修改密码', component: () => import('../views/password')},
      { path: 'user', name: '用户管理', component: () => import('../views/sys/User')},
      { path: 'icon', name: '图标管理', component: () => import('../views/sys/icon')},
      { path: 'stocks', name: '物资库存', component: () => import('../views/product/stocks')},
      { path: 'person', name: '个人信息', component: () => import('../views/person')},
      { path: 'file', name: '文件管理', component: () => import('../views/sys/file')},
      { path: 'category', name: '物资分类', component: () => import('../views/product/category')},
      { path: '/notice', name: '公告信息', component: () => import('../views/notice/notice')},
      { path: '/addNotice', name: '发布公告', component: () => import('../views/notice/add')},
      { path: '/product', name: '物资信息', component: () => import('../views/product/products')},
      { path: '/log', name: '日志信息', component: () => import('../views/monitor/log')},
      { path: '/outList', name: '出库列表', component: () => import('../views/exwarehouse/list')},
      { path: '/outAdd', name: '出库添加', component: () => import('../views/exwarehouse/add')},
      { path: '/inAdd', name: '入库添加', component: () => import('../views/warehousing/add')},
      { path: '/inList', name: '入库列表', component: () => import('../views/warehousing/list')},
      { path: '/supplier', name: '物资来源', component: () => import('../views/whereabouts/supplier')},
      { path: '/consumer', name: '物资来源', component: () => import('../views/whereabouts/consumer')},
      { path: '/role', name: '物资来源', component: () => import('../views/Role')},
      { path: '/menu', name: '物资来源', component: () => import('../views/Menu')},
    ]
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login.vue')
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('../views/Register.vue')
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

// 路由守卫
router.beforeEach((to, from, next) => {
  localStorage.setItem("currentPathName", to.name)  // 设置当前的路由名称，为了在Header组件中去使用
  store.commit("setPath")  // 触发store的数据更新
  next()  // 放行路由
})

export default router