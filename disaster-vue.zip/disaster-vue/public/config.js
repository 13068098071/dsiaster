export const serverIp = 'localhost'
